package Project;

import Project.controllers.BookManager;
import Project.models.Book;
import Project.services.BookDataService;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;
public class Main {
    public static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) throws IOException {
        String choose = null;
        boolean exit = false;
        BookManager bookManager = new BookManager("./resources/book-input.txt");
        showMenu();
              while (true) {
            choose = scanner.nextLine();
            switch (choose) {
                case "1":
                    System.out.println("Add Book");
                    bookManager.addBook(scanner);
                    break;
                case "2":
                    System.out.println("Edit Author");
                    System.out.println("Enter id: ");
                    int bookId = scanner.nextInt();                
                    scanner.nextLine();
                    bookManager.editAuthor(bookId);
                    break;
                
                case "3":
                    System.out.println("Delete Price");
                    System.out.println("Enter price: ");
                    String bookPrice = scanner.nextLine();
                    scanner.nextLine();
                    bookManager.deletePrice(bookPrice);
                    break;
                 case "4":
                    System.out.println("Delete Name you need");
                    System.out.println("Enter Name you want: ");
                    String bookName = scanner.nextLine();
                    scanner.nextLine();
                    bookManager.deletePrice(bookName);
                    break;
                    
                 case "5":
                    System.out.println("Delete Isbn you need ");
                    System.out.println("Enter Isbn: ");
                    String bookIsbn = scanner.nextLine();
                    scanner.nextLine();
                    bookManager.deleteIsbn(bookIsbn);
                    break;
                case "6":
                    System.out.println("Sort By Id you want");
                    bookManager.sortById();
                    break;
                case "7" : 
                    System.out.println("Sort by Language you want ");
                    bookManager.sortByLanguage();
                case "8":
                    System.out.println("Sort by Name you want");
                    bookManager.sortByName();
                    break;
                case "9" : 
                    System.out.println("Sort by Author you want ");
                    bookManager.sortByAuthor();
                case "10 " : 
                    System.out.println("Sort by Price you want");
                    bookManager.sortByPrice();
                    
                case "11":
                    System.out.println("Books");
                    bookManager.showAll();
                    break;
                case "0":
                    System.out.println("Exit");
                    exit = true;
                    break;
                default:
                    System.out.println(" Choose case you want !");
                    break;
            }
            if (exit) {
                break;
            }
            showMenu();
        }
    }
     public static void showMenu() {
        System.out.println("------Menu------");
        System.out.println("1. Add Book");
        System.out.println("2. Edit Author");
        System.out.println("3. Delete Price");
        System.out.println("4. Delete Name ");
        System.out.println("5. Delete Isbn");
        System.out.println("6. Sort books by Id");
        System.out.println("7. Sort By Language");
        System.out.println("8. Sort By Name");
        System.out.println("9. Sort By  Auhor");
        System.out.println("10. Sort By Price");
        System.out.println("11. All Books");
        System.out.println("0. Exit");
        System.out.println("-----------------");
        System.out.println("Choose case you Need : ");
    }

}
