package Project.controllers;

import Project.models.Book;
import Project.services.BookDataService;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
public class BookManager {
    private List<Book> list;
    private final String pathFileToInput;
    private BookDataService service;
    public BookManager(String pathFileToInput) {
        this.pathFileToInput = pathFileToInput;
        this.service = new BookDataService();
        try {
            this.list = service.read(pathFileToInput);
        } catch (IOException e) {
        }
    }
     public void sortByName() {
        Collections.sort(list, (t1, t2) -> t1.getName().compareTo(t2.getName()));
    }
    public void sortByPrice() {
        Collections.sort(list, (t1, t2) -> t1.getName().compareTo(t2.getName()));
    }
    public void sortByLanguage() {
        Collections.sort(list, (t1, t2) -> t1.getLanguage().compareTo(t2.getLanguage()));
    }
    public void sortByAuthor() {
        Collections.sort(list, (t1, t2) -> t1.getLanguage().compareTo(t2.getLanguage()));
    }
    public void sortById() {
        Collections.sort(list, (t1, t2) -> Integer.compare(t1.getId(), t2.getId()));
    }
    
    public Book findByName(String name) {     
        for (Book t : list) {
            if (t.getName().equals(name)) {
                return t;
            }
        }
        return null;
    }
    public Book findByLanguage(String language) {     
        for (Book t : list) {
            if (t.getName().equals(language)) {
                return t;
            }
        }
        return null;
    }
    public Book findById( int id) {
        for (Book t : list) {
            if (t.getId() == id) {
                return t;
            }
        }
        return null;
    }
    public Book findByPrice( String price) {
        for (Book t : list) {
            if (t.getPrice().equals(price)) {
                return t;
            }
        }
        return null;
    }
    public Book findByPublish( String publish) {
        for (Book t : list) {
            if (t.getPrice().equals(publish)) {
                return t;
            }
        }
        return null;
    }
    public Book findByAuthor( String publish) {
        for (Book t : list) {
            if (t.getPrice().equals(publish)) {
                return t;
            }
        }
        return null;
    }
    public Book findByIsbn( String isbn) {
        for (Book t : list) {
            if (t.getPrice().equals(isbn)) {
                return t;
            }
        }
        return null;
    }
    public Book findBook( String name) {
        for (Book t : list) {
            if (t.getPrice().equals(name)) {
                showAll();
            }
        }
        return null;
    }
    public void showAll() {
        for (Book t : list) {
            System.out.println(t.toString());
        }
    }
    public void deleteName(String name) {
        Book findByName = findByName(name);
        list.remove(findByName);
    }
    public void deleteIsbn(String isbn) {
        Book findByIsbn = findByIsbn(isbn);
        list.remove(findByIsbn);
    }
    public void deletePrice(String price) {
        Book findByPrice = findByPrice(price);
        list.remove(findByPrice);
    }
    public void deleteId(int id) {
        Book findById = findById(id);
        list.remove(findById);
    }
    
      public void editAuthor(int id) {
        Book book = findById( id);
        Scanner scanner = new Scanner(System.in);
        System.out.println("Type name you want: ");
        String newAuthor = scanner.nextLine();
        book.setAuthor(newAuthor);
    }
      public void editIsbn(int id) {
        Book book = findById( id);
        Scanner scanner = new Scanner(System.in);
        System.out.println("Type name you want: ");
        String newIsbn = scanner.nextLine();
        book.setIsbn(newIsbn);
    }
    public void addBook(Scanner sc) {
        list.add(new Book().input(sc));
    }
}